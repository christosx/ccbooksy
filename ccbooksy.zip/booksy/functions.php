<?php

// Config database
if($_SERVER['SERVER_NAME'] == "localhost")
{
    define('DBUSER',"root");
    define('DBPASS',"");
    define('DBNAME',"booksy");
    define('DBHOST',"localhost");

}else
{
    define('DBUSER',""); // set DBUSER here
    define('DBPASS',""); // set DBPASS here
    define('DBNAME',"booksy");
    define('DBHOST',"localhost");
}


// Make a query for fetching from database
function query(string $query, array $data = [])
{

    $string = "mysql:hostname=".DBHOST.";dbname=". DBNAME;
    $con = new PDO($string, DBUSER, DBPASS);

    $stm = $con->prepare($query);
    $stm->execute($data);

    $result = $stm->fetchAll(PDO::FETCH_ASSOC);
    if(is_array($result) && !empty($result))
    {
        return $result;
    }

    return false;

}


// Make a query_row for fetching from database
function query_row(string $query, array $data = [])
{

    $string = "mysql:hostname=".DBHOST.";dbname=". DBNAME;
    $con = new PDO($string, DBUSER, DBPASS);

    $stm = $con->prepare($query);
    $stm->execute($data);

    $result = $stm->fetchAll(PDO::FETCH_ASSOC);
    if(is_array($result) && !empty($result))
    {
        return $result[0];
    }

    return false;

}


//create_tables();
function create_tables()
{

    $string = "mysql:hostname=".DBHOST.";";
    $con = new PDO($string, DBUSER, DBPASS);

    $query = "create database if not exists ". DBNAME;
    $stm = $con->prepare($query);
    $stm->execute();

    $query = "use ". DBNAME;
    $stm = $con->prepare($query);
    $stm->execute();

    /** users table **/
    $query = "create table if not exists users(

        id int primary key auto_increment,
        username varchar(50) not null,
        email varchar(100) not null,
        password varchar(255) not null,
        date datetime default current_timestamp,
        role varchar(50) not null,

        key username (username),
        key email (email)

    )";
    $stm = $con->prepare($query);
    $stm->execute();

    /** appointments table **/
    $query = "create table if not exists appointments(

        id int primary key auto_increment,
        app_full_date varchar(255) null,
        app_full_date_numeric varchar(255) null,
        app_day_name varchar(50) null,
        app_day_number varchar(50) null,
        app_month varchar(50) null,
        app_year varchar(50) null,
        full_name varchar(255) null,
        phone_number varchar(50) null,
        persons_number int,
        app_time varchar(50) null,
        app_time_numeric decimal(19,2) null,
        date datetime default current_timestamp

    )";
    $stm = $con->prepare($query);
    $stm->execute();

    /** settings table **/
    $query = "create table if not exists settings(

        id int not null,
        workers int,
        working_days varchar(1024) null,
        working_hours varchar(1024) null,
        break_hours varchar(1024) null,
        half_days varchar(1024) null,
        half_days_hours varchar(1024) null,
        app_time_span int,
        public_holidays text null,
        personal_holidays text null,
        app_timezone varchar(1024) null

    )";
    $stm = $con->prepare($query);
    $stm->execute();

    /** password reset table **/
    $query = "create table if not exists pwdReset(

        id int(11) primary key auto_increment not null,
        email text not null,
        selector text not null,
        token longtext not null,
        expires text not null

    )";
    $stm = $con->prepare($query);
    $stm->execute();

}


// Escape string
function esc($str)
{
    return htmlspecialchars($str ?? '');
}

// Get leap year
function leap_year($year) {
    // Use the ternary operator to check if the year is a leap year 
    return ($year % 100 === 0) ? ($year % 400 === 0) : ($year % 4 === 0); 
}


// Set Session Message
function set_message($msg) {
    if(!empty($msg)) {
        $_SESSION['MESSAGE'] = $msg;
    } else {
        $msg = '';
    }
}


// Display Message
function display_message() {
    if (isset($_SESSION['MESSAGE'])) {
        echo $_SESSION['MESSAGE'];
        unset($_SESSION['MESSAGE']);
    }
}


// Authencticate user login
function authenticate($row)
{
    $_SESSION['USER'] = $row;
}


// Old Value of input
function old_value($key, $default = '')
{
    if(!empty($_POST[$key]))
        return $_POST[$key];

    return $default;
}