<?php require_once('functions.php'); ?>
<?php create_tables(); ?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>CC Booksy | Appointments booking web application</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="icon" type="image/x-icon" href="img/cc_favicon.png">

	<script src="js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body>

	<div class="page-loader-wrapper"><span class="page-loader"></span></div>

	<div class="main-container">

		<div class="page-title">
			<h1>BOOK APPOINTMENT</h1>
			<h3>CC Booksy</h3>
		</div>

		<div class="calendar-container">
			<div class="pending-appointments">
			<?php
				if (isset($_COOKIE['booksy_app'])) {
					$cookie_value = $_COOKIE['booksy_app'];
					$apps_num = substr($cookie_value, strpos($cookie_value, "|") + 1);

					if ($apps_num == 1) {
						echo '<div><i class="fa-regular fa-clock pending-icon"></i> You have '.$apps_num.' pending appointment!</div>';
					} else {
						echo '<div><i class="fa-regular fa-clock pending-icon"></i> You have '.$apps_num.' pending appointments!</div>';
					}
				}
			?>
			</div>

			<?php 
				$query_db = "select * from settings limit 1;";
				$row_db = query_row($query_db);
			?>

			<input type="hidden" name="working_days_hidden_input" id="working_days_hidden_input" value="<?=$row_db['working_days']?>">
			<input type="hidden" name="public_holidays_hidden_input" id="public_holidays_hidden_input" value="<?=$row_db['public_holidays']?>">

	        <header class="calendar-header">
	            <p class="calendar-current-date"></p>
	            <div class="calendar-navigation">
	                <span id="calendar-prev"
	                      class="material-symbols-rounded">
	                    chevron_left
	                </span>
	                <span id="calendar-next"
	                      class="material-symbols-rounded">
	                    chevron_right
	                </span>
	            </div>
	        </header>
	 
	        <div class="calendar-body">
	            <ul class="calendar-weekdays">
	                <li>Sun</li>
	                <li>Mon</li>
	                <li>Tue</li>
	                <li>Wed</li>
	                <li>Thu</li>
	                <li>Fri</li>
	                <li>Sat</li>
	            </ul>
	            <ul class="calendar-dates"></ul>
	        </div>

	        <span id="date-info" class="validate-info"></span>
	    </div><!-- /calendar-container -->

	    <div class="app-info-container">
			<div class="input-area user-name">
				<label for="userName">Full Name (required)</label>
				<input type="text" name="userName" id="userName" class="inputBox" placeholder="Your Full Name">
				<span id="userName-info" class="validate-info"></span>
			</div>
			<div class="input-area phone-area">
				<label for="userPhone">Phone Number (required)</label>
				<input type="number" name="userPhone" id="userPhone" class="inputBox" placeholder="Your Phone Number">
				<span id="userPhone-info" class="validate-info"></span>
			</div>

			<div class="persons-area">
				<span class="input-title">Number of persons</span>
				<label for="personsNum_1" class="radio">
					<input type="radio" name="personsNum" id="personsNum_1" class="radio-el" value="1" checked>
					<span>1 person</span>
				</label>
				<?php if ($row_db == true && $row_db['workers'] > 1) { ?>
				<label for="personsNum_2" class="radio">
					<input type="radio" name="personsNum" id="personsNum_2" class="radio-el" value="2">
					<span>2 persons</span>
				</label>
				<?php } ?>
				<?php if ($row_db == true && $row_db['workers'] > 2) { ?>
				<label for="personsNum_3" class="radio">
					<input type="radio" name="personsNum" id="personsNum_3" class="radio-el" value="3">
					<span>3 persons</span>
				</label>
				<?php } ?>
			</div>

			<div class="time-table">

				<?php require_once('app-time-table.php'); ?>
				
			</div>

			<div class="book-app-btn-area">
		    	<button type="button" id="bookApp" onclick="bookApp();">BOOK APPOINTMENT</button>
		    </div>
	    </div><!-- /app-info-container -->

	    <div class="confirmation-modal"></div><!-- /confirmation-modal -->
	    <div class="modal-bg"></div>

	</div><!-- /main-container -->

	<div class="footer">
		<p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
	</div>

</body>

	<script type="text/javascript">
		setTimeout(() => {

			$(".page-loader-wrapper").css('opacity', '0');

		}, 2000)
	</script>
	
	<script src="js/calendar.js"></script>

	<script type="text/javascript">// Add checked attribute to radio inputs
		$('input:radio[name=personsNum]').change(function() {
            if (this.value == '1') {
                $("#personsNum_1").attr('checked', true);
                $("#personsNum_2").attr("checked", false);
                $("#personsNum_3").attr("checked", false);
            }
            else if (this.value == '2') {
                $("#personsNum_1").attr("checked", false);
                $("#personsNum_2").attr("checked", true);
                $("#personsNum_3").attr("checked", false);
            }
            else if (this.value == '3') {
                $("#personsNum_1").attr("checked", false);
                $("#personsNum_2").attr("checked", false);
                $("#personsNum_3").attr("checked", true);
            }
   		});
	</script>

	<script type="text/javascript">
		// add 'selected' class on clicked date
		document.addEventListener('click', function handleClick(event) {
			if (event.target.classList.contains('time-stamp')){
				$(".time-table .selected-time").removeClass("selected-time");
				event.target.classList.add('selected-time');
			}
		});
	</script>

	<script type="text/javascript">
		const get_date = new Date();
		var current_day = get_date.getDate();
		var current_month = get_date.getMonth();
		var current_year = get_date.getFullYear();

		switch(current_month) {
		  case 0:
		    current_month = 'January';
		    break;
		  case 1:
		    current_month = 'February';
		    break;
		  case 2:
		    current_month = 'March';
		    break;
		  case 3:
		    current_month = 'April';
		    break;
		  case 4:
		    current_month = 'May';
		    break;
		  case 5:
		    current_month = 'June';
		    break;
		  case 6:
		    current_month = 'July';
		    break;
		  case 7:
		    current_month = 'August';
		    break;
		  case 8:
		    current_month = 'September';
		    break;
		  case 9:
		    current_month = 'October';
		    break;
		  case 10:
		    current_month = 'November';
		    break;
		  case 11:
		    current_month = 'December';
		    break;
		  default:
		  	current_month = current_month;
		    break;
		}

		// Reload page with new url
		window.onload = function() { 

			var checkUrl = window.location.href;

			if (checkUrl.endsWith("/home.php")) {
				var siteUrl = checkUrl.split('home.php')[0]; // Remove everything after the first occurrence of a character
				location.replace(siteUrl+'home.php?day='+current_day+'&month='+current_month+'&year='+current_year);
			}

			// Check if there are inactive workers - used for personal hoiidays
			var check_el = false;
			var inactive_workers = 0;
			document.addEventListener( "click", ckeckClassName ); // on click enable function
			function ckeckClassName(event){
		      	check_el = event.target.classList.contains('inactive-workers');
		      	if (check_el == true) {
		      		var getClasses = event.target.classList;
		      		inactive_workers = getClasses[4].slice(getClasses[4].indexOf('workers-') + 8); // get string after a specific character
		      	}
		    }
		    if (check_el == true) {
		    	inactive_workers = inactive_workers;
		    } else {
		    	inactive_workers = 0;
		    }
		    // end of check

			setTimeout(() => {
				$.ajax({
			        url: "app-time-table.php",
			        type: "POST",
			        data:'day='+current_day+'&month='+current_month+'&year='+current_year+'&inactive_workers='+inactive_workers, 
			        success: function (html) {
			        	$(".time-table").html(html);
			        }
			    });
		    }, 0) // 1500

		}

		function getDateValue(value) {
			var get_dayNumber = $('.selected-date').text(); // get content of a div
			var get_monthYear = $('.calendar-current-date').text(); // get content of a div
			let get_words = get_monthYear;
			var get_wordArray = [];
			get_wordArray = get_words.split(' ');
			var get_month = get_wordArray[0];
			var get_year = get_wordArray[1];

			// used for page get value
			var currentUrl = window.location.href;

			// push new url
			var newurl = "/booksy/home.php?day="+value+"&month="+get_month+"&year="+get_year;
			window.history.pushState("object or string", "Title", newurl);

			// Get day name
			var half_day = new Date(get_month + value + ', ' + get_year);
			var half_day_cal = half_day.getDay();

			if (half_day_cal == 6) {
				$.ajax({
			        type: "POST",
			        success: function (html) {
			        	
			        }
			    });
			}

			// Check if there are inactive workers - used for personal hoiidays
			var check_el = false;
			var inactive_workers = 0;
			document.addEventListener( "click", ckeckClassName ); // on click enable function
			function ckeckClassName(event){
		      	check_el = event.target.classList.contains('inactive-workers');
		      	if (check_el == true) {
		      		var getClasses = event.target.classList;
		      		inactive_workers = getClasses[4].slice(getClasses[4].indexOf('workers-') + 8); // get string after a specific character
		      	}
		    }
		    if (check_el == true) {
		    	inactive_workers = inactive_workers;
		    } else {
		    	inactive_workers = 0;
		    }
		    // end of check

			$('#app-time-table-loader').addClass('show-app-time-table-loader');

			setTimeout(() => {
				$.ajax({
			        url: "app-time-table.php",
			        type: "POST",
			        data:'day='+value+'&month='+get_month+'&year='+get_year+'&inactive_workers='+inactive_workers, 
			        success: function (html) {
			        	$(".time-table").html(html);
			        	$('#app-time-table-loader').removeClass('show-app-time-table-loader');
			        }
			    });
		    }, 1500) // 1500
		}
	</script>

	<script type="text/javascript">
		function bookApp() {

			var dayNumber = $('.selected-date').text(); // get content of a div
			var monthYear = $('.calendar-current-date').text(); // get content of a div
			let words = monthYear;
			var wordArray = [];
  			wordArray = words.split(' ');
  			var month = wordArray[0];
  			var year = wordArray[1];

			const d = new Date(month + dayNumber + ', ' + year);
			let day = d.getDay();

			// get userInputs value
			var userName = $('#userName').val();
			var userPhone = $('#userPhone').val();
			var personsNum = document.querySelector('input[name="personsNum"]:checked').value;

			if (personsNum == '1') {
				var modalPersonsStr = '<span>For ' + personsNum + ' person</span>';
			} else {
				var modalPersonsStr = '<span>For ' + personsNum + ' persons</span>';
			}

			// get appointment time and spots
			var selectedTime = $('.selected-time').text(); // get content of a div
			var timeVal = selectedTime.split(' ')[0]; // Remove everything after the first occurrence of a character
			var spotsVal = selectedTime.split('(').pop(); // Removes part of string before
			spotsVal = spotsVal.slice(0, -1); // Remove the last character

			var valid;	
			valid = validateAppointment();

			if (valid) {

				if (day == '0') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Sunday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '1') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Monday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '2') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Tuesday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '3') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Wednesday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '4') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Thursday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '5') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Friday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				} else if (day == '6') {
					$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to book the appointment on' + '<span class="final-date">Saturday ' + dayNumber + ' of ' + monthYear + ' at ' + timeVal + '</span>' + modalPersonsStr + '<button type="submit" name="book_now_btn" class="book-btn" onclick="bookNow();">Book Me Now</button>');
				}

				$('.confirmation-modal').addClass('show-confirmation-modal');
				$('.modal-bg').addClass('show-modal-bg');

				$(".close-btn").click(function(){
					$('.confirmation-modal').removeClass('show-confirmation-modal');
					$('.modal-bg').removeClass('show-modal-bg');
				});

			}
		
		}

		function validateAppointment() {
			var valid = true;	
			$(".validate-info").html('');

			if(!$(".date-number").hasClass('selected-date')) {
				$("#date-info").html("Please select appointment date");
				valid = false;
			}
			
			if(!$("#userName").val()) {
				$("#userName-info").html("Please enter your full name");
				valid = false;
			}

			if(!$("#userPhone").val()) {
				$("#userPhone-info").html("Please enter your phone number");
				valid = false;
			}
			if(!$("#userPhone").val().match(/^([+0-9\s]{8,20})?$/)) {
				$("#userPhone-info").html("Please enter a valid phone number");
				valid = false;
			}
			
			if(!$(".time-stamp").hasClass('selected-time')) {
				$("#time-info").html("Please select appointment time");
				valid = false;
			}
			
			return valid;
		}

		function bookNow() {

			var dayNumber = $('.selected-date').text(); // get content of a div
			var monthYear = $('.calendar-current-date').text(); // get content of a div
			let words = monthYear;
			var wordArray = [];
  			wordArray = words.split(' ');
  			var month = wordArray[0];
  			var year = wordArray[1];

  			// get userInputs value
			var userName = $('#userName').val();
			var userPhone = $('#userPhone').val();
			var personsNum = document.querySelector('input[name="personsNum"]:checked').value;

			// get appointment time and spots
			var selectedTime = $('.selected-time').text(); // get content of a div
			var timeVal = selectedTime.split(' ')[0]; // Remove everything after the first occurrence of a character
			var spotsVal = selectedTime.split('(').pop(); // Removes part of string before
			spotsVal = spotsVal.slice(0, -1); // Remove the last character

			// Check if there are inactive workers - used for personal hoiidays
			var check_el = false;
			var inactive_workers = 0;
		 	check_el = document.querySelector('.date-number-'+dayNumber).classList.contains('inactive-workers');
		 	if (check_el == true) {
	      		var getClasses = document.querySelector('.date-number-'+dayNumber).classList;
	      		inactive_workers = getClasses[4].slice(getClasses[4].indexOf('workers-') + 8); // get string after a specific character
	      	}
		    if (check_el == true) {
		    	inactive_workers = inactive_workers;
		    } else {
		    	inactive_workers = 0;
		    }
		    // end of check

			var workers = $('#workersInput').val();

			$.ajax({
		        url: "book-app-controller.php",
		        type: "POST",
		        data:'dayNumber='+dayNumber+'&month='+month+'&year='+year+'&userName='+userName+'&userPhone='+userPhone+'&personsNum='+personsNum+'&timeVal='+timeVal+'&workers='+workers+'&inactive_workers='+inactive_workers,
		        success: function (html) {
		        	$('.confirmation-modal').html(html);
		        	
		        	$(".close-btn").click(function(){
						$('.confirmation-modal').removeClass('show-confirmation-modal');
						$('.modal-bg').removeClass('show-modal-bg');

						$('#app-time-table-loader').addClass('show-app-time-table-loader');

						setTimeout(() => {
							$.ajax({
						        url: "app-time-table.php",
						        type: "POST",
						        data:'day='+dayNumber+'&month='+month+'&year='+year+'&inactive_workers='+inactive_workers,
						        success: function (html) {
						        	$(".time-table").html(html);
						        	$('#app-time-table-loader').removeClass('show-app-time-table-loader');
						        }
						    });
					    }, 1500) // 1500
					});

				    $('.pending-appointments').html('<div><i class="fa-regular fa-circle-check pending-icon"></i> Appointment booked successfully!</div>');
				  
		        }
		    });

		}
	</script>

	<script type="text/javascript">
		// CREATES A COOKIE (EXPIRES IN 30 DAYS)
		function setCookie(cName, cValue, expDays) {
		  let date = new Date();
		  date.setTime(date.getTime() + (expDays * 24 * 60 * 60 * 1000));
		  const expires = "expires=" + date.toUTCString();
		  document.cookie = cName + "=" + cValue + "; " + expires + "; path=/";
		}

		// GRAB THE VALUE OF THE COOKIE
		function getCookie(cName) {
		  const name = cName + "=";
		  const cDecoded = decodeURIComponent(document.cookie);
		  const cArr = cDecoded .split('; ');
		  let res;
		  cArr.forEach(val => {
		      if (val.indexOf(name) === 0) res = val.substring(name.length);
		  })
		  return res;
		}

		// Set app cookie
		if (getCookie("booksy_app") != null) {
			setCookie("booksy_app", getCookie("booksy_app"), 7); // set cookie for 365 days
		} else {
			setCookie("booksy_app", "", 7); // set cookie for 365 days
		}
	</script>

</html>