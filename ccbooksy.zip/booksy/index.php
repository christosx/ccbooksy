<?php require_once('functions.php'); ?>
<?php create_tables(); ?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Booksy | Appointments booking web application</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<!-- <link rel="icon" type="image/x-icon" href="img/cc_favicon.png"> -->

	<script src="js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body>

<?php 

	header('Location: home.php');

?>

</body>
</html>