<?php

require_once ('functions.php');

$dayNumber = esc($_POST['dayNumber']);
$month = esc($_POST['month']);
$date = date_parse($month);
$month_number = $date['month'];
$year = esc($_POST['year']);
$date_numeric = $year.'-'.$month_number.'-'.$dayNumber;
$userName = esc($_POST['userName']);
$userPhone = esc($_POST['userPhone']);
$personsNum = esc($_POST['personsNum']);
$timeVal = esc($_POST['timeVal']);
$workers = esc($_POST['workers']);

$data = [];
$data['dayNumber'] = $dayNumber;
$data['month'] = $month;
$data['year'] = $year;
$data['date_numeric'] = $date_numeric;
$data['userName'] = $userName;
$data['userPhone'] = $userPhone;
$data['personsNum'] = $personsNum;
$data['timeVal'] = $timeVal;
$data['timeValNumeric'] = str_replace(":",".",$timeVal);
$fullDate = $dayNumber . ' ' . $month . ' ' . $year;
$data['fullDate'] = $fullDate;

//creating a valid date format
$datetime = DateTimeImmutable::createFromFormat('j M Y', $fullDate);
$appDayName = $datetime->format('D');
$data['appDayName'] = $appDayName;


$data_sel = [];
$data_sel['timeVal'] = $timeVal;
$query_sel = "select persons_number from appointments where app_time = :timeVal and (app_full_date like '$fullDate%') and (app_full_date like '%$fullDate');";
$rows = query($query_sel, $data_sel);

if ($rows) {
	$count = count($rows);

	if ($count >= $workers) {
		echo '<i class="fa-solid fa-xmark close-btn"></i><i class="fa-solid fa-xmark error-icon"></i><span class="error-message">No available spots at ' . $timeVal . ' in our shop!</span>';
		exit();
	} else {
		foreach ($rows as $row) {
			$sum = $row['persons_number'] + $personsNum;
			$allowed = $workers - $row['persons_number'];
			if ($sum > $workers) {
				echo '<i class="fa-solid fa-xmark close-btn"></i><i class="fa-solid fa-xmark error-icon"></i><span class="error-message">Allowed persons at ' . $timeVal . ' is ' . $allowed . '</span>';
				exit();
			}
		}
	}
} elseif ($personsNum > $workers) {
	echo '<i class="fa-solid fa-xmark close-btn"></i><i class="fa-solid fa-xmark error-icon"></i><span class="error-message">Allowed persons at ' . $timeVal . ' is ' . $workers . '</span>';
	exit();
}

if (isset($_COOKIE['booksy_app'])) {
	$cookie_value = $_COOKIE['booksy_app'];
	$apps_num = substr($cookie_value, strpos($cookie_value, "|") + 1);

	if ($apps_num < 3) {
		if ($apps_num == '' || $apps_num == null) {
			$apps_num = 1;
		} else {
			$apps_num = $apps_num + 1;
		}

		$cookie_value = $userName.'/'.$dayNumber.'/'.$month.'/'.$year.'/'.$timeVal.'|'.$apps_num;
		setcookie('booksy_app', $cookie_value, time() + (86400 * 7)); // 86400 = 1 day
	} else {
		echo '<i class="fa-solid fa-xmark close-btn"></i><i class="fa-solid fa-xmark error-icon"></i><span class="error-message">Maximum appointments allowed per week are 3</span>';
		exit();
	}
}

$query = "insert into appointments (app_full_date,app_full_date_numeric,app_day_name,app_day_number,app_month,app_year,full_name,phone_number,persons_number,app_time,app_time_numeric) values (:fullDate,:date_numeric,:appDayName,:dayNumber,:month,:year,:userName,:userPhone,:personsNum,:timeVal,:timeValNumeric)";
query($query, $data);

echo '<i class="fa-solid fa-xmark close-btn"></i><div class="success-checkmark"><div class="check-icon"><span class="icon-line line-tip"></span><span class="icon-line line-long"></span><div class="icon-circle"></div><div class="icon-fix"></div></div></div>Thank you for choosing our shop!';

