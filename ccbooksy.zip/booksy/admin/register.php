<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php create_tables(); ?>

<?php 
	if (isset($_COOKIE['EMAIL']) && isset($_COOKIE['PASSWORD'])) {
	    header('Location: home.php?page=1');
	} elseif (!empty($_POST)) {
		// validate form
		$errors = [];

		$query = "select id from users where username = :username limit 1";
    	$username = query($query, ['username'=>$_POST['username']]);

    	$query = "select id from users where email = :email limit 1";
    	$useremail = query($query, ['email'=>$_POST['email']]);

		if (empty($_POST['username'])) {
	      $errors['username'] = "Username is required";
	    } elseif (!preg_match("/^[a-zA-Z0-9]+$/", $_POST['username'])) {
	      $errors['username'] = "Username can only have letters and numbers with no spaces";
	    } elseif ($username) {
	      $errors['username'] = "The username is taken";
	    }

	    if (empty($_POST['email'])) {
	      $errors['email'] = "Email is required";
	    } elseif (!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)) {
	      $errors['email'] = "Please enter a valid email";
	    } elseif ($useremail) {
	      $errors['email'] = "This email address is already registered";
	    }

	    if (empty($_POST['password'])) {
	      $errors['password'] = "Password is required";
	    } elseif (strlen($_POST['password']) < 8) {
	      $errors['password'] = "Password must be 8 characters or more";
	    } elseif ($_POST['password'] !== $_POST['password-repeat']) {
	      $errors['password'] = "Passwords do not match";
	    }

	    if(empty($errors)) {
	      //save to database
	      $data = [];
	      $data['username'] = $_POST['username'];
	      $data['email']    = $_POST['email'];

	      $query = "SELECT role FROM users WHERE role='admin' LIMIT 1;";
	      $rows = query($query);
	      
	      if ($rows) {
	        foreach ($rows as $row) {
	          if ($row["role"] == 'admin') {
	            $data['role'] = "user";
	          }
	        }
	      } else {
	        $data['role'] = "admin";
	      }
	     
	      $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);

	      $query = "insert into users (username,email,password,role) values (:username,:email,:password,:role)";
	      query($query, $data);

	      header('Location: login.php');
	    }
	}
?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Admin | CC Booksy - Register</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
	<link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

	<script src="../js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel register-page">

	<div class="main-container">

		<div class="page-title">
			<h1>Admin Register</h1>
			<h3>CC Booksy</h3>
		</div>

		<div class="main-content">
			<form class="register-form" action="register.php" method="POST" autocomplete="off">
				<div class="input-area">
					<label for="username">Username *</label>
					<input type="text" name="username" id="username" class="inputBox" placeholder="Your username" value="<?=old_value('username')?>">
					<?php if(!empty($errors['username'])):?>
					<div class="error-alert"><?=$errors['username']?></div>
					<?php endif;?>
				</div>
				<div class="input-area">
					<label for="email">Email Address *</label>
					<input type="email" name="email" id="email" class="inputBox" placeholder="Your email address" value="<?=old_value('email')?>">
					<?php if(!empty($errors['email'])):?>
					<div class="error-alert"><?=$errors['email']?></div>
					<?php endif;?>
				</div>
				<div class="input-area">
					<label for="password">Password *</label>
					<input type="password" name="password" id="password" class="inputBox" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" value="<?=old_value('password')?>">
					<i class="bi bi-eye-slash" id="togglePassword"></i>
					<?php if(!empty($errors['password'])):?>
					<div class="error-alert"><?=$errors['password']?></div>
					<?php endif;?>
				</div>
				<div class="input-area">
					<label for="password-repeat">Repeat Password *</label>
					<input type="password" name="password-repeat" id="password-repeat" class="inputBox" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" value="<?=old_value('password-repeat')?>">
					<i class="bi bi-eye-slash" id="togglePasswordRepeat"></i>
				</div>
				<button type="submit" name="submit-btn" class="submit-btn">REGISTER</button>
			</form>
		</div>

	</div>

	<div class="footer">
		<p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
	</div>

</body>
	
	<script type="text/javascript"> // toogle password visibility
		const password = document.querySelector("#password");
		const togglePassword = document.querySelector("#togglePassword");

		togglePassword.addEventListener("click", function () {
            // toggle the type attribute
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            
            // toggle the icon
            this.classList.toggle("bi-eye");
        });

        const passwordRepeat = document.querySelector("#password-repeat");
		const togglePasswordRepeat = document.querySelector("#togglePasswordRepeat");

		togglePasswordRepeat.addEventListener("click", function () {
            // toggle the type attribute
            const type = passwordRepeat.getAttribute("type") === "password" ? "text" : "password";
            passwordRepeat.setAttribute("type", type);
            
            // toggle the icon
            this.classList.toggle("bi-eye");
        });
	</script>

</html>