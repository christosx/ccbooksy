<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php create_tables(); ?>

<?php 

$user = $_SESSION['USER'];
if(!isset($user))
{
  header('Location: login.php');
}

if($user['role'] != 'admin') 
{
  header('Location: login.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Admin | CC Booksy - Appointments</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

	<script src="../js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel appointments-page">

	<div class="main-container">

		<div class="page-title">
			<h1>ADMIN PANEL</h1>
			<h3>CC Booksy</h3>
		</div>

		<div class="main-menu">
			<ul>
				<li><a href="home.php?page=1" class="active">APPOINTMENTS</a></li>
				<li><a href="book.php">BOOK</a></li>
				<li><a href="settings.php">SETTINGS</a></li>
				<li><a href="logout.php">LOGOUT</a></li>
			</ul>
		</div><!-- /main-menu -->

		<div class="main-content">
			<?php require_once('date-area-content.php'); ?>
		</div><!-- /main-content -->

	</div><!-- /main-container -->

	<div class="confirmation-modal"></div><!-- /confirmation-modal -->
	<div class="modal-bg"></div>

	<div class="footer">
		<p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
	</div>

</body>
	
	<script type="text/javascript">
		function navDateNext() {
			var url = window.location.href;
			var page = url.split('?page=').pop(); // Removes part of string before

			if (url.endsWith("/home.php?page="+page)) {
				page++;
				var siteUrl = url.split('home.php')[0]; // Remove everything after the first occurrence of a character
				// push new url
				var newurl = siteUrl+"home.php?page="+page;
				window.history.pushState("object or string", "Title", newurl);
			}

			setTimeout(() => {
				$.ajax({
			        url: "date-area-content.php",
			        type: "POST",
			        data:'page='+page, 
			        success: function (html) {
			        	$(".appointments-page .main-content").html(html);
			        }
			    });
		    }, 0) // 1500
		}

		function navDatePrev() {
			var url = window.location.href;
			var page = url.split('?page=').pop(); // Removes part of string before

			if (url.endsWith("/home.php?page="+page)) {
				if (page == 1) {
					$page = 1;
				} else {
					page--;
				}
	
				var siteUrl = url.split('home.php')[0]; // Remove everything after the first occurrence of a character
				// push new url
				var newurl = siteUrl+"home.php?page="+page;
				window.history.pushState("object or string", "Title", newurl);
			}

			setTimeout(() => {
				$.ajax({
			        url: "date-area-content.php",
			        type: "POST",
			        data:'page='+page, 
			        success: function (html) {
			        	$(".appointments-page .main-content").html(html);
			        }
			    });
		    }, 0) // 1500
		}
	</script>

	<script type="text/javascript">
		function deleteApp(id, name, time, persons_num) {
			if (persons_num == 1) {
				var plural = 'person';
			} else {
				var plural = 'persons';
			}

			$('.confirmation-modal').html('<i class="fa-solid fa-xmark close-btn"></i>' + 'Are you sure you want to delete the appointment' + '<span class="app-details">' + name + ' at ' + time + ' for ' + persons_num + ' ' + plural + '</span><button type="submit" name="delete_now_btn" class="delete-btn" onclick="deleteAppNow('+id+');">Delete Now</button>');

			$('.confirmation-modal').addClass('show-confirmation-modal');
			$('.modal-bg').addClass('show-modal-bg');

			$(".close-btn").click(function(){
				$('.confirmation-modal').removeClass('show-confirmation-modal');
				$('.modal-bg').removeClass('show-modal-bg');
			});
		}

		function deleteAppNow(id) {
			var id = id;
			var url = window.location.href;
			var page = url.split('?page=').pop(); // Removes part of string before

			$.ajax({
		        url: "delete-app-controller.php",
		        type: "POST",
		        data:'id='+id, 
		        success: function (html) {
		        	$(".confirmation-modal").html(html);

		        	$(".close-btn").click(function(){
						$('.confirmation-modal').removeClass('show-confirmation-modal');
						$('.modal-bg').removeClass('show-modal-bg');
					});
		        }
		    });

		    setTimeout(() => {
				$.ajax({
			        url: "date-area-content.php",
			        type: "POST",
			        data:'page='+page, 
			        success: function (html) {
			        	$(".appointments-page .main-content").html(html);
			        }
			    });
		    }, 0) // 1500
		}
	</script>

</html>