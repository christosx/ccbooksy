<?php require_once('../functions.php'); ?>

<?php 

$id = $_POST['id'];

$data = [];
$data['id'] = $id;
$query = "delete from appointments where id = :id;";
query($query, $data);

echo '<i class="fa-solid fa-xmark close-btn"></i><div class="success-checkmark"><div class="check-icon"><span class="icon-line line-tip"></span><span class="icon-line line-long"></span><div class="icon-circle"></div><div class="icon-fix"></div></div></div>Appointment deleted successfully!';