<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php create_tables(); ?>

<?php 
	if ( (isset($_COOKIE['USERNAME']) || isset($_COOKIE['EMAIL'])) && isset($_COOKIE['PASSWORD']) ) {
	    header('Location: home.php?page=1');
	} elseif (!empty($_POST)) {
		$errors = [];
		$data = [];
		$data['username'] = $_POST['username-email'];
		$data['email'] = $_POST['username-email'];
		$query = "select * from users where email = :email or username = :username limit 1";
	    $row = query($query, $data);
	    $remember = isset($_POST['remember-me']);

	    if($row) {
	      if(password_verify($_POST['password'], $row[0]['password'])) {
	        if ($remember == 1) {
	        	setcookie('USERNAME', $row[0]['username'], time()+86400*30);
	         	setcookie('EMAIL', $row[0]['email'], time()+86400*30);
	          	setcookie('PASSWORD', $row[0]['password'], time()+86400*30);
	        }

	        if ($row[0]['role'] == 'admin') {
	        	//grant access
		        authenticate($row[0]);
		        header('Location: home.php?page=1');
	        } else {
	        	$errors['email'] = "You have no administrator access";
	        }

	      } else {
	        $errors['email'] = "Wrong username/email or password";
	      }
	    } else {
	      $errors['email'] = "Wrong username/email or password";
	    }
	} else {
		unset($_SESSION['USER']);
	}
?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Admin | CC Booksy - Login</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
	<link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

	<script src="../js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel login-page">

	<div class="main-container">

		<div class="page-title">
			<h1>Admin Login</h1>
			<h3>CC Booksy</h3>
		</div>

		<div class="main-content">
			<form class="login-form" action="login.php" method="POST" autocomplete="off">
				<?php 
					if (isset($_GET['newpwd'])) {
						if ($_GET['newpwd'] == 'passwordupdated') {
							echo '<p class="success-alert">Password updated successfully.</p>';
						}
					}
				?>
				<div class="input-area">
					<?php if(!empty($errors['email'])):?>
					<div class="error-alert"><?=$errors['email']?></div>
					<?php endif;?>
					<label for="username-email">Username or Email Address *</label>
					<input type="text" name="username-email" id="username-email" class="inputBox" placeholder="Your Username or Email Address" value="<?=old_value('username-email')?>">
				</div>
				<div class="input-area">
					<label for="password">Password *</label>
					<input type="password" name="password" id="password" class="inputBox" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" value="<?=old_value('password')?>">
					<i class="bi bi-eye-slash" id="togglePassword"></i>
				</div>
				<a href="forgot-password.php" class="forgot-pass-link">
					<small>Forgot Password?</small>
                </a>
				<label for="remember-me" class="check-box">
					<input type="checkbox" name="remember-me" id="remember-me" class="inputCheck" value="1">
					<span>Remember me for 30 days</span>
				</label>
				<button type="submit" name="submit-btn" class="submit-btn">LOGIN</button>
			</form>
		</div>

	</div>

	<div class="footer">
		<p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
	</div>

</body>

	<script type="text/javascript"> // toogle password visibility
		const password = document.querySelector("#password");
		const togglePassword = document.querySelector("#togglePassword");

		togglePassword.addEventListener("click", function () {
            // toggle the type attribute
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            
            // toggle the icon
            this.classList.toggle("bi-eye");
        });
	</script>

</html>