<?php require_once('set_session.php'); ?>
<?php require_once ('../functions.php'); ?>

<!DOCTYPE html>
<html>
<head>
  
  <meta charset="UTF-8">
  <title>Admin | CC Booksy - Password Reset</title>
  <meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
  <meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
  <link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

  <script src="../js/jquery.js"></script>

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel new-password-page">

  <div class="main-container">

    <div class="page-title">
      <h1>Admin New Password</h1>
      <h3>CC Booksy</h3>
    </div>

    <div class="main-content">

      <?php 

        $selector = $_GET['selector'];
        $validator = $_GET['validator'];

        if (isset($_GET['newpwd'])) {
          $pwdError = $_GET['newpwd'];
        }
        

        if (empty($selector) || empty($validator)) { 
          echo "Could not validate your request!";
        } else {
          if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
            ?>

            <form action="includes/reset-password.php" method="POST">

              <h4>New Password Request. 🔒</h4>
              <p>Please enter your new password</p>
              
              <input type="hidden" name="selector" value="<?php echo $selector; ?>">
              <input type="hidden" name="validator" value="<?php echo $validator; ?>">

              <?php if ( isset($_GET['newpwd']) && $pwdError == 'pwderror' ) { ?>
              <div class="error-alert">Please enter a password!</div>
              <?php } elseif ( isset($_GET['newpwd']) && $pwdError == 'pwdrepeaterror' ) { ?>
              <div class="error-alert">Passwords do not match!</div>
              <?php } elseif ( isset($_GET['newpwd']) && $pwdError == 'pwdlengtherror' ) { ?>
              <div class="error-alert">Password must be 8 character or more!</div>
              <?php } ?>

              <div class="input-area">
                <label class="form-label" for="pwd">Password</label>
                <input
                  type="password"
                  id="pwd"
                  class="form-control"
                  name="pwd"
                  placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                  aria-describedby="password"
                  value="<?=old_value('password')?>"
                />
                <i class="bi bi-eye-slash" id="togglePassword"></i>
              </div>
              <div class="input-area">
                <label class="form-label" for="pwd-repeat">Retype Password</label>
                <input
                  type="password"
                  id="pwd-repeat"
                  class="form-control"
                  name="pwd-repeat"
                  placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                  aria-describedby="pwd-repeat"
                  value="<?=old_value('pwd-repeat')?>"
                />
                <i class="bi bi-eye-slash" id="togglePasswordRepeat"></i>
              </div>

              <button type="submit" name="reset-password-submit" class="submit-btn">Reset password</button>
            </form>
            
            <?php
          }
        }

      ?>
    </div>

  </div>

  <div class="footer">
    <p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
  </div>

</body>

  <script type="text/javascript"> // toogle password visibility
    const password = document.querySelector("#pwd");
    const togglePassword = document.querySelector("#togglePassword");

    togglePassword.addEventListener("click", function () {
            // toggle the type attribute
            const type = password.getAttribute("type") === "password" ? "text" : "password";
            password.setAttribute("type", type);
            
            // toggle the icon
            this.classList.toggle("bi-eye");
        });

    const passwordRepeat = document.querySelector("#pwd-repeat");
    const togglePasswordRepeat = document.querySelector("#togglePasswordRepeat");

    togglePasswordRepeat.addEventListener("click", function () {
            // toggle the type attribute
            const type = passwordRepeat.getAttribute("type") === "password" ? "text" : "password";
            passwordRepeat.setAttribute("type", type);
            
            // toggle the icon
            this.classList.toggle("bi-eye");
        });
  </script>

</html>
