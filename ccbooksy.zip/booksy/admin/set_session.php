<?php 

	function sessionStart($lifetime, $path, $domain, $secure, $httpOnly) {

		session_set_cookie_params($lifetime, $path, $domain, $secure, $httpOnly);

		session_start();
		session_regenerate_id(true);

	}

	if ( (isset($_COOKIE['USERNAME']) || isset($_COOKIE['EMAIL'])) && isset($_COOKIE['PASSWORD'])) {
		$lifetime = 86400 * 30; // 30 days
		ini_set('session.gc_maxlifetime', $lifetime);
	} else {
		$lifetime = 86400 * 1; // 1 days
		ini_set('session.gc_maxlifetime', $lifetime);
	}

	// Current Session Timeout Value
	// $currentTimeout= ini_get('session.gc_maxlifetime');

	$http_host = $_SERVER['HTTP_HOST'];
	sessionStart($lifetime, '/', $http_host, false, true);