<?php 

	function sessionStart($lifetime, $path, $domain, $secure, $httpOnly) {

		session_set_cookie_params($lifetime, $path, $domain, $secure, $httpOnly);

		session_start();
		session_regenerate_id(false);

	}

	if ( (isset($_COOKIE['USERNAME']) || isset($_COOKIE['EMAIL'])) && isset($_COOKIE['PASSWORD'])) {
		$lifetime = 86400 * 30; // 30 days
	} else {
		$lifetime = 86400 * 1; // 1 days
	}

	$http_host = $_SERVER['HTTP_HOST'];
	sessionStart($lifetime, '/', $http_host, false, true);