<?php 

require_once '../../functions.php';

if (isset($_POST['reset-password-submit'])) {

	$selector = $_POST['selector'];
	$validator = $_POST['validator'];
	$password = $_POST['pwd'];
	$passwordRepeat = $_POST['pwd-repeat'];

	$currentDate = date("U");

	$query = "select * from pwdreset where selector = :selector and expires >= $currentDate;";

	$data = [];
	$data['selector'] = $selector;

	// FETCHING DATA FROM DATABASE
	$rows = query_row($query, $data);

	if (empty($rows)) {

		echo "You need to resubmit your reset request.";
		exit();

	} else {

		$tokenBin = hex2bin($validator);
		$tokenCheck = password_verify($tokenBin, $rows["token"]);

		if ($tokenCheck === false) {

			echo "You need to resubmit your reset request.";
			exit();

		} elseif ($tokenCheck === true) {

			$tokenEmail = $rows['email'];

			$query = "select * from users where email=:email;";

			$data = [];
			$data['email'] = $tokenEmail;

			$rows = query($query, $data);

			if (empty($rows)) {

				echo "There was an error!";
				exit();

			} else {

				if ( empty($password) ) {

					header("Location: ../create-new-password.php?selector=" . $selector . "&validator=" . $validator . "&newpwd=pwderror");

				} elseif ( $password != $passwordRepeat ) {

					header("Location: ../create-new-password.php?selector=" . $selector . "&validator=" . $validator . "&newpwd=pwdrepeaterror");

				} elseif ( strlen($password) < 8 ) {

					header("Location: ../create-new-password.php?selector=" . $selector . "&validator=" . $validator . "&newpwd=pwdlengtherror");

				} else {

					// update with the new password in users table
					$query = "update users set password = :password where email = :email;";

					$data = [];
					$data['email'] = $tokenEmail;
					$data['password'] = password_hash($password, PASSWORD_DEFAULT);

					$rows = query($query, $data);

					// delete row from pwdreset table
					$query = "delete from pwdreset where email=:email;";

					$data= [];
					$data['email'] = $tokenEmail;

					query($query, $data);

					header("Location: ../login.php?newpwd=passwordupdated");

				}

			}

		}

	}

} else {

	header("Location: ../index.php");

}

?>