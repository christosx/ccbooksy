<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php create_tables(); ?>

<?php 

$user = $_SESSION['USER'];
if(!isset($user))
{
  header('Location: login.php');
}

if($user['role'] != 'admin') 
{
  header('Location: login.php');
}

?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<title>Admin | CC Booksy - Settings</title>
	<meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
	<meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
	<link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

	<script src="../js/jquery.js"></script>

	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel settings-page">

	<div class="main-container">

		<div class="page-title">
			<h1>ADMIN PANEL</h1>
			<h3>CC Booksy</h3>
		</div>

		<div class="main-menu">
			<ul>
				<li><a href="home.php?page=1">APPOINTMENTS</a></li>
				<li><a href="book.php">BOOK</a></li>
				<li><a href="settings.php"  class="active">SETTINGS</a></li>
				<li><a href="logout.php">LOGOUT</a></li>
			</ul>
		</div><!-- /main-menu -->

		<?php if (isset($_SESSION['MESSAGE']) != '') { ?>
			<?php if (isset($_GET['save']) == 'success') { ?>
				<div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> <?php display_message(); ?></div>
			<?php } ?>
		<?php } ?>

		<?php 
			$query = "select * from settings;";
			$row = query_row($query);

			// working days
			$workingDays = $row['working_days'];
			$workingDays_array = array();
			$workingDays_array = explode(',', $workingDays);

			// half days
			$halfDays = $row['half_days'];
			$halfDays_array = array();
			$halfDays_array = explode(',', $halfDays);

			// working hours
			$workingHours = $row['working_hours'];

			$position = strpos($workingHours, '-'); // remove after
			if ($position !== false) {
			  $workingHours_start = substr($workingHours, 0, $position);
			}

			$workingHours_end = strstr($workingHours, '-'); // remove before
			$workingHours_end = ltrim($workingHours_end, $workingHours_end[0]); // remove first character of the string

			// break hours
			$breakHours = $row['break_hours'];

			$position = strpos($breakHours, '-'); // remove after
			if ($position !== false) {
			  $breakHours_start = substr($breakHours, 0, $position);
			}

			$breakHours_end = strstr($breakHours, '-'); // remove before
			$breakHours_end = ltrim($breakHours_end, $breakHours_end[0]); // remove first character of the string

			// half days hours
			$halfDaysHours = $row['half_days_hours'];

			$position_half = strpos($halfDaysHours, '-'); // remove after
			if ($position_half !== false) {
			  $halfDaysHours_start = substr($halfDaysHours, 0, $position_half);
			}

			$halfDaysHours_end = strstr($halfDaysHours, '-'); // remove before
			$halfDaysHours_end = ltrim($halfDaysHours_end, $halfDaysHours_end[0]); // remove first character of the string
		?>

		<form class="settings-container" action="settings-controller.php" method="POST">

			<div class="input-area">
				<label for="workersInput">Number of workers</label>
				<input type="number" name="workersInput" id="workersInput" class="inputBox" value="<?=$row['workers']?>" min="1">
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Working Days</label>
				<div class="ckeck-boxes">
					<label for="workingDaysMon" class="check-box">
						<input type="checkbox" name="workingDaysInput_mon" id="workingDaysMon" class="inputCheck" value="Mon" <?php if (in_array('Mon', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Monday</span>
					</label>
					<label for="workingDaysTue" class="check-box">
						<input type="checkbox" name="workingDaysInput_tue" id="workingDaysTue" class="inputCheck" value="Tue" <?php if (in_array('Tue', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Tuesday</span>
					</label>
					<label for="workingDaysWed" class="check-box">
						<input type="checkbox" name="workingDaysInput_wed" id="workingDaysWed" class="inputCheck" value="Wed" <?php if (in_array('Wed', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Wednesday</span>
					</label>
					<label for="workingDaysThu" class="check-box">
						<input type="checkbox" name="workingDaysInput_thu" id="workingDaysThu" class="inputCheck" value="Thu" <?php if (in_array('Thu', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Thursday</span>
					</label>
					<label for="workingDaysFri" class="check-box">
						<input type="checkbox" name="workingDaysInput_fri" id="workingDaysFri" class="inputCheck" value="Fri" <?php if (in_array('Fri', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Friday</span>
					</label>
					<label for="workingDaysSat" class="check-box">
						<input type="checkbox" name="workingDaysInput_sat" id="workingDaysSat" class="inputCheck" value="Sat" <?php if (in_array('Sat', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Saturday</span>
					</label>
					<label for="workingDaysSun" class="check-box">
						<input type="checkbox" name="workingDaysInput_sun" id="workingDaysSun" class="inputCheck" value="Sun" <?php if (in_array('Sun', $workingDays_array)) { echo 'checked'; } ?>>
						<span>Sunday</span>
					</label>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Working Hours</label>
				<div class="working-hours">
					<div class="time-select">
						<label>Start time</label>
						<select name="select-working-time-start">
							<option value="6.00" <?php if ($row == true && $workingHours_start == 6.00) { echo 'selected'; } ?>>6:00</option>
							<option value="6.50" <?php if ($row == true && $workingHours_start == 6.50) { echo 'selected'; } ?>>6:30</option>
							<option value="7.00" <?php if ($row == true && $workingHours_start == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $workingHours_start == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $workingHours_start == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $workingHours_start == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $workingHours_start == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $workingHours_start == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $workingHours_start == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $workingHours_start == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $workingHours_start == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $workingHours_start == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $workingHours_start == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $workingHours_start == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $workingHours_start == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $workingHours_start == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $workingHours_start == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $workingHours_start == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $workingHours_start == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $workingHours_start == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $workingHours_start == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $workingHours_start == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $workingHours_start == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $workingHours_start == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $workingHours_start == 18.00) { echo 'selected'; } ?>>18:00</option>
						</select>
					</div>
					<div class="time-select">
						<label>End time</label>
						<select name="select-working-time-end">
							<option value="7.00" <?php if ($row == true && $workingHours_end == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $workingHours_end == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $workingHours_end == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $workingHours_end == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $workingHours_end == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $workingHours_end == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $workingHours_end == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $workingHours_end == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $workingHours_end == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $workingHours_end == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $workingHours_end == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $workingHours_end == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $workingHours_end == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $workingHours_end == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $workingHours_end == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $workingHours_end == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $workingHours_end == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $workingHours_end == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $workingHours_end == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $workingHours_end == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $workingHours_end == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $workingHours_end == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $workingHours_end == 18.00) { echo 'selected'; } ?>>18:00</option>
							<option value="18.50" <?php if ($row == true && $workingHours_end == 18.50) { echo 'selected'; } ?>>18:30</option>
							<option value="19.00" <?php if ($row == true && $workingHours_end == 19.00) { echo 'selected'; } ?>>19:00</option>
							<option value="19.50" <?php if ($row == true && $workingHours_end == 19.50) { echo 'selected'; } ?>>19:30</option>
							<option value="20.00" <?php if ($row == true && $workingHours_end == 20.00) { echo 'selected'; } ?>>20:00</option>
							<option value="20.50" <?php if ($row == true && $workingHours_end == 20.50) { echo 'selected'; } ?>>20:30</option>
							<option value="21.00" <?php if ($row == true && $workingHours_end == 21.00) { echo 'selected'; } ?>>21:00</option>
							<option value="21.50" <?php if ($row == true && $workingHours_end == 21.50) { echo 'selected'; } ?>>21:30</option>
							<option value="22.00" <?php if ($row == true && $workingHours_end == 22.00) { echo 'selected'; } ?>>22:00</option>
							<option value="22.50" <?php if ($row == true && $workingHours_end == 22.50) { echo 'selected'; } ?>>22:30</option>
							<option value="23.00" <?php if ($row == true && $workingHours_end == 23.00) { echo 'selected'; } ?>>23:00</option>
						</select>
					</div>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Break Hours</label>
				<div class="working-hours">
					<div class="time-select">
						<label>Start time</label>
						<select name="select-break-time-start">
							<option value="6.00" <?php if ($row == true && $breakHours_start == 6.00) { echo 'selected'; } ?>>6:00</option>
							<option value="6.50" <?php if ($row == true && $breakHours_start == 6.50) { echo 'selected'; } ?>>6:30</option>
							<option value="7.00" <?php if ($row == true && $breakHours_start == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $breakHours_start == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $breakHours_start == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $breakHours_start == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $breakHours_start == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $breakHours_start == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $breakHours_start == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $breakHours_start == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $breakHours_start == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $breakHours_start == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $breakHours_start == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $breakHours_start == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $breakHours_start == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $breakHours_start == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $breakHours_start == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $breakHours_start == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $breakHours_start == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $breakHours_start == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $breakHours_start == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $breakHours_start == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $breakHours_start == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $breakHours_start == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $breakHours_start == 18.00) { echo 'selected'; } ?>>18:00</option>
						</select>
					</div>
					<div class="time-select">
						<label>End time</label>
						<select name="select-break-time-end">
							<option value="7.00" <?php if ($row == true && $breakHours_end == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $breakHours_end == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $breakHours_end == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $breakHours_end == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $breakHours_end == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $breakHours_end == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $breakHours_end == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $breakHours_end == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $breakHours_end == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $breakHours_end == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $breakHours_end == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $breakHours_end == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $breakHours_end == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $breakHours_end == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $breakHours_end == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $breakHours_end == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $breakHours_end == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $breakHours_end == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $breakHours_end == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $breakHours_end == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $breakHours_end == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $breakHours_end == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $breakHours_end == 18.00) { echo 'selected'; } ?>>18:00</option>
							<option value="18.50" <?php if ($row == true && $breakHours_end == 18.50) { echo 'selected'; } ?>>18:30</option>
							<option value="19.00" <?php if ($row == true && $breakHours_end == 19.00) { echo 'selected'; } ?>>19:00</option>
							<option value="19.50" <?php if ($row == true && $breakHours_end == 19.50) { echo 'selected'; } ?>>19:30</option>
							<option value="20.00" <?php if ($row == true && $breakHours_end == 20.00) { echo 'selected'; } ?>>20:00</option>
							<option value="20.50" <?php if ($row == true && $breakHours_end == 20.50) { echo 'selected'; } ?>>20:30</option>
							<option value="21.00" <?php if ($row == true && $breakHours_end == 21.00) { echo 'selected'; } ?>>21:00</option>
							<option value="21.50" <?php if ($row == true && $breakHours_end == 21.50) { echo 'selected'; } ?>>21:30</option>
							<option value="22.00" <?php if ($row == true && $breakHours_end == 22.00) { echo 'selected'; } ?>>22:00</option>
							<option value="22.50" <?php if ($row == true && $breakHours_end == 22.50) { echo 'selected'; } ?>>22:30</option>
							<option value="23.00" <?php if ($row == true && $breakHours_end == 23.00) { echo 'selected'; } ?>>23:00</option>
						</select>
					</div>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Half Working Days</label>
				<div class="ckeck-boxes">
					<label for="halfWorkingDaysMon" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_mon" id="halfWorkingDaysMon" class="inputCheck" value="Mon" <?php if (in_array('Mon', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Monday</span>
					</label>
					<label for="halfWorkingDaysTue" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_tue" id="halfWorkingDaysTue" class="inputCheck" value="Tue" <?php if (in_array('Tue', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Tuesday</span>
					</label>
					<label for="halfWorkingDaysWed" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_wed" id="halfWorkingDaysWed" class="inputCheck" value="Wed" <?php if (in_array('Wed', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Wednesday</span>
					</label>
					<label for="halfWorkingDaysThu" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_thu" id="halfWorkingDaysThu" class="inputCheck" value="Thu" <?php if (in_array('Thu', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Thursday</span>
					</label>
					<label for="halfWorkingDaysFri" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_fri" id="halfWorkingDaysFri" class="inputCheck" value="Fri" <?php if (in_array('Fri', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Friday</span>
					</label>
					<label for="halfWorkingDaysSat" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_sat" id="halfWorkingDaysSat" class="inputCheck" value="Sat" <?php if (in_array('Sat', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Saturday</span>
					</label>
					<label for="halfWorkingDaysSun" class="check-box">
						<input type="checkbox" name="halfWorkingDaysInput_sun" id="halfWorkingDaysSun" class="inputCheck" value="Sun" <?php if (in_array('Sun', $halfDays_array)) { echo 'checked'; } ?>>
						<span>Sunday</span>
					</label>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Half Days Working Hours</label>
				<div class="working-hours">
					<div class="time-select">
						<label>Start time</label>
						<select name="select-halfday-working-time-start">
							<option value="6.00" <?php if ($row == true && $halfDaysHours_start == 6.00) { echo 'selected'; } ?>>6:00</option>
							<option value="6.50" <?php if ($row == true && $halfDaysHours_start == 6.50) { echo 'selected'; } ?>>6:30</option>
							<option value="7.00" <?php if ($row == true && $halfDaysHours_start == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $halfDaysHours_start == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $halfDaysHours_start == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $halfDaysHours_start == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $halfDaysHours_start == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $halfDaysHours_start == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $halfDaysHours_start == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $halfDaysHours_start == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $halfDaysHours_start == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $halfDaysHours_start == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $halfDaysHours_start == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $halfDaysHours_start == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $halfDaysHours_start == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $halfDaysHours_start == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $halfDaysHours_start == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $halfDaysHours_start == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $halfDaysHours_start == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $halfDaysHours_start == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $halfDaysHours_start == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $halfDaysHours_start == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $halfDaysHours_start == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $halfDaysHours_start == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $halfDaysHours_start == 18.00) { echo 'selected'; } ?>>18:00</option>
						</select>
					</div>
					<div class="time-select">
						<label>End time</label>
						<select name="select-halfday-working-time-end">
							<option value="7.00" <?php if ($row == true && $halfDaysHours_end == 7.00) { echo 'selected'; } ?>>7:00</option>
							<option value="7.50" <?php if ($row == true && $halfDaysHours_end == 7.50) { echo 'selected'; } ?>>7:30</option>
							<option value="8.00" <?php if ($row == true && $halfDaysHours_end == 8.00) { echo 'selected'; } ?>>8:00</option>
							<option value="8.50" <?php if ($row == true && $halfDaysHours_end == 8.50) { echo 'selected'; } ?>>8:30</option>
							<option value="9.00" <?php if ($row == true && $halfDaysHours_end == 9.00) { echo 'selected'; } ?>>9:00</option>
							<option value="9.50" <?php if ($row == true && $halfDaysHours_end == 9.50) { echo 'selected'; } ?>>9:30</option>
							<option value="10.00" <?php if ($row == true && $halfDaysHours_end == 10.00) { echo 'selected'; } ?>>10:00</option>
							<option value="10.50" <?php if ($row == true && $halfDaysHours_end == 10.50) { echo 'selected'; } ?>>10:30</option>
							<option value="11.00" <?php if ($row == true && $halfDaysHours_end == 11.00) { echo 'selected'; } ?>>11:00</option>
							<option value="11.50" <?php if ($row == true && $halfDaysHours_end == 11.50) { echo 'selected'; } ?>>11:30</option>
							<option value="12.00" <?php if ($row == true && $halfDaysHours_end == 12.00) { echo 'selected'; } ?>>12:00</option>
							<option value="12.50" <?php if ($row == true && $halfDaysHours_end == 12.50) { echo 'selected'; } ?>>12:30</option>
							<option value="13.00" <?php if ($row == true && $halfDaysHours_end == 13.00) { echo 'selected'; } ?>>13:00</option>
							<option value="13.50" <?php if ($row == true && $halfDaysHours_end == 13.50) { echo 'selected'; } ?>>13:30</option>
							<option value="14.00" <?php if ($row == true && $halfDaysHours_end == 14.00) { echo 'selected'; } ?>>14:00</option>
							<option value="14.50" <?php if ($row == true && $halfDaysHours_end == 14.50) { echo 'selected'; } ?>>14:30</option>
							<option value="15.00" <?php if ($row == true && $halfDaysHours_end == 15.00) { echo 'selected'; } ?>>15:00</option>
							<option value="15.50" <?php if ($row == true && $halfDaysHours_end == 15.50) { echo 'selected'; } ?>>15:30</option>
							<option value="16.00" <?php if ($row == true && $halfDaysHours_end == 16.00) { echo 'selected'; } ?>>16:00</option>
							<option value="16.50" <?php if ($row == true && $halfDaysHours_end == 16.50) { echo 'selected'; } ?>>16:30</option>
							<option value="17.00" <?php if ($row == true && $halfDaysHours_end == 17.00) { echo 'selected'; } ?>>17:00</option>
							<option value="17.50" <?php if ($row == true && $halfDaysHours_end == 17.50) { echo 'selected'; } ?>>17:30</option>
							<option value="18.00" <?php if ($row == true && $halfDaysHours_end == 18.00) { echo 'selected'; } ?>>18:00</option>
							<option value="18.50" <?php if ($row == true && $halfDaysHours_end == 18.50) { echo 'selected'; } ?>>18:30</option>
							<option value="19.00" <?php if ($row == true && $halfDaysHours_end == 19.00) { echo 'selected'; } ?>>19:00</option>
							<option value="19.50" <?php if ($row == true && $halfDaysHours_end == 19.50) { echo 'selected'; } ?>>19:30</option>
							<option value="20.00" <?php if ($row == true && $halfDaysHours_end == 20.00) { echo 'selected'; } ?>>20:00</option>
							<option value="20.50" <?php if ($row == true && $halfDaysHours_end == 20.50) { echo 'selected'; } ?>>20:30</option>
							<option value="21.00" <?php if ($row == true && $halfDaysHours_end == 21.00) { echo 'selected'; } ?>>21:00</option>
							<option value="21.50" <?php if ($row == true && $halfDaysHours_end == 21.50) { echo 'selected'; } ?>>21:30</option>
							<option value="22.00" <?php if ($row == true && $halfDaysHours_end == 22.00) { echo 'selected'; } ?>>22:00</option>
							<option value="22.50" <?php if ($row == true && $halfDaysHours_end == 22.30) { echo 'selected'; } ?>>22:30</option>
							<option value="23.00" <?php if ($row == true && $halfDaysHours_end == 23.00) { echo 'selected'; } ?>>23:00</option>
						</select>
					</div>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label class="titleLabel">Appointment Time Span</label>
				<div class="working-hours">
					<div class="time-select">
						<label>Time Slot Span</label>
						<select name="select-time-span">
							<option value="10" <?php if ($row == true && $row['app_time_span'] == 10) { echo 'selected'; } ?>>10 min</option>
							<option value="20" <?php if ($row == true && $row['app_time_span'] == 20) { echo 'selected'; } ?>>20 min</option>
							<option value="30" <?php if ($row == true && $row['app_time_span'] == 30) { echo 'selected'; } ?>>30 min</option>
							<option value="40" <?php if ($row == true && $row['app_time_span'] == 40) { echo 'selected'; } ?>>40 min</option>
							<option value="50" <?php if ($row == true && $row['app_time_span'] == 50) { echo 'selected'; } ?>>50 min</option>
							<option value="60" <?php if ($row == true && $row['app_time_span'] == 60) { echo 'selected'; } ?>>1 hr</option>
						</select>
					</div>
				</div>
			</div><!-- /input-area -->

			<div class="input-area">
				<label for="public-holidays" class="titleLabel">Public Holidays</label>
				<textarea name="public-holidays" id="public-holidays" class="text-area-input" cols="60" rows="4" placeholder="Add public holidays separated by comma ( , ). ex. 25/12,1/1"><?php echo ($row) ? $row['public_holidays'] : ''; ?></textarea>
			</div><!-- /input-area -->

			<div class="personal-holidays-area">
			<?php
				if ($row['personal_holidays'] != '' || !empty($row['personal_holidays']) || $row['personal_holidays'] != null) {
					$perHolArray = explode('|', $row['personal_holidays']);
					$countPerHol = count($perHolArray);
					echo '<input type="hidden" id="countPerHol" value="'.$countPerHol.'">';

					for ($i = 0; $i < $countPerHol; $i++) {
						$perHolStart = substr($perHolArray[$i], 0, strpos($perHolArray[$i], ",end")); // removes the string after a certain character
						$perHolStart = strstr($perHolStart, 'start='); // removes the string before a certain character
						$perHolStart = str_replace('start=', '', $perHolStart); // remove specific characters from the string

						$perHolEnd = substr($perHolArray[$i], 0, strpos($perHolArray[$i], ",workers")); // removes the string after a certain character
						$perHolEnd = strstr($perHolEnd, 'end='); // removes the string before a certain character
						$perHolEnd = str_replace('end=', '', $perHolEnd); // remove specific characters from the string

						$perHolWorkers = substr($perHolArray[$i], 0, strpos($perHolArray[$i], ")")); // removes the string after a certain character
						$perHolWorkers = strstr($perHolWorkers, 'workers='); // removes the string before a certain character
						$perHolWorkers = str_replace('workers=', '', $perHolWorkers); // remove specific characters from the string
						
						$value = $i + 1;
						
						echo '<div class="personal-holidays personal-holidays-'.$value.'">'.
						'<div class="title"><label class="titleLabel titleLabel-'.$value.'">Personal Holidays #'.$value.'</label>';

						if ($value == $countPerHol) {
							echo '<button type="button" id="remove_holidays_btn_'.$value.'" class="remove-holidays-btn">REMOVE</button>';
						}

						echo '</div>'.
						'<div class="start-date-area"><label>Start date</label><input type="text" name="startDateHol_'.$value.'" class="inputBox" placeholder="13/08/2024" value="'.$perHolStart.'"></div>'.
						'<div class="end-date-area"><label>End date</label><input type="text" name="endDateHol_'.$value.'" class="inputBox" placeholder="22/08/2024" value="'.$perHolEnd.'"></div>'.
						'<div class="number-of-workers-area"><label>Number of workers</label><input type="number" name="workersHol_'.$value.'" class="inputBox" value="'.$perHolWorkers.'" min="1" max="'.$row['workers'].'"></div>'.
						'<input type="hidden" name="personal_holidays_num" value="'.$value.'">'.
						'</div>';
					}
				}
			?>
			</div><!-- /personal-holidays-area -->

			<button type="button" class="btn-btn" onclick="addPersonalHolidays();">ADD PERSONAL HOLIDAYS</button>

			<button type="submit" name="btn_submit_settings" id="btn-submit-settings" class="btn-submit"><i class="fa-solid fa-floppy-disk"></i> SAVE SETTINGS</button>

		</form><!-- /settings-container -->

	</div><!-- /main-container -->

	<div class="footer">
		<p>Copyright <?=date('Y')?> © Booksy. Designed & Developed by Christos Christoforou.</p>
	</div>

</body>
	
	<script type="text/javascript">
		var workers = $("#workersInput").val();
		var value = $("#countPerHol").val();
		if (value == null || value == 'Nan' || value == 'undefined') {
			value = 0;
		} else if (value != '' || value != 0) {
			value = value;
		} else {
			value = 0;
		}

		function addPersonalHolidays() {
			$("#remove_holidays_btn_"+value).remove();

			value++;

			// push new url
			var newurl = "/booksy/admin/settings.php?personal_holidays="+value;
			window.history.pushState("object or string", "Title", newurl);
			
			$(".personal-holidays-area").append('<div class="personal-holidays personal-holidays-'+value+'">'+
				'<div class="title"><label class="titleLabel titleLabel-'+value+'">Personal Holidays #'+value+'</label><button type="button" id="remove_holidays_btn_'+value+'" class="remove-holidays-btn">REMOVE</button></div>'+
				'<div class="start-date-area"><label>Start date</label><input type="text" name="startDateHol_'+value+'" class="inputBox" placeholder="13/8/2024"></div>'+
				'<div class="end-date-area"><label>End date</label><input type="text" name="endDateHol_'+value+'" class="inputBox" placeholder="22/8/2024"></div>'+
				'<div class="number-of-workers-area"><label>Number of workers</label><input type="number" name="workersHol_'+value+'" class="inputBox" value="1" min="1" max="'+workers+'"></div>'+
				'<input type="hidden" name="personal_holidays_num" value="'+value+'">'+
				'</div>');
		}


		document.addEventListener( "click", removeHolidaysBtn ); // on click enable function removeHolidayBtn
		function removeHolidaysBtn(event){
	      	var element = event.target.id;
	    	var element_check = element.substr(0, element.lastIndexOf("_"));

	    	if (element_check == "remove_holidays_btn") {

				var holidays_number = element.replace('remove_holidays_btn_', '');
				holidays_number = Number(holidays_number);

				holidays_number--;

				// push new url
				var newurl = "/booksy/admin/settings.php?personal_holidays="+holidays_number;
				window.history.pushState("object or string", "Title", newurl);

				var remove_holidays_number = holidays_number + 1; 
				$(".personal-holidays-"+remove_holidays_number).remove();

				$('.titleLabel-'+holidays_number).after('<button type="button" id="remove_holidays_btn_'+holidays_number+'" class="remove-holidays-btn">REMOVE</button>');

				value--;

	    	}
	      
	  	}
	</script>

</html>