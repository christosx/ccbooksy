<?php require_once('set_session.php'); ?>

<?php 


if(!empty($_SESSION['USER'])) {

	unset($_SESSION['USER']);
	unset($_COOKIE['EMAIL']);
	unset($_COOKIE['PASSWORD']);
	setcookie('EMAIL', '', time()-86400*30);
	setcookie('PASSWORD', '', time()-86400*30);
}
	

header('Location: login.php');