<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>
<?php create_tables(); ?>

<?php 

$expired = date("U") - 1800;

$query = "delete from pwdreset where expires < $expired;";

query($query);

?>

<!DOCTYPE html>
<html>
<head>
  
  <meta charset="UTF-8">
  <title>Admin | CC Booksy - Password Reset</title>
  <meta name="description" content="Book your appointmnets with booksy webapp. A light and nimble php plugin for small businesses.">
  <meta name="keywords" content="website, portfolio, design, web, app, application, developer, limassol, cyprus, christos, christoforou, appointments, booking, plugin, php, barbershop">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <link rel="stylesheet" href="../style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
  <link rel="icon" type="image/x-icon" href="../img/cc_favicon.png">

  <script src="../js/jquery.js"></script>

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">

</head>
<body class="admin_panel forgot-password-page">

  <div class="main-container">

    <div class="page-title">
      <h1>Admin Password Reset</h1>
      <h3>CC Booksy</h3>
    </div>

    <div class="main-content">
      <form autocomplete="off" action="includes/reset-request.php" method="POST">
        <h4>Forgot Password? 🔒</h4>
        <p>Enter your email and we'll send you instructions to reset your password</p>

        <?php
          if (isset($_GET["reset"])) {
            if ($_GET["reset"] == "success") {
              echo '<p class="success-alert">Check you email! Do not forget to check your spam/junk as well.</p>';
            }
          }
        ?>

        <?php if (isset($_SESSION['MESSAGE']) != '') { ?>
        <div class="error-alert"><?php display_message(); ?></div>
        <?php } ?>

        <div class="input-area">
          <label for="email">Email Address *</label>
          <input type="text" name="email" id="email" class="inputBox" placeholder="Enter Your Email Address" value="<?=old_value('email')?>">
        </div>
        <button type="submit" name="reset-request-submit">Send Reset Link</button>
        <a href="login.php"><i class="fa-solid fa-angle-left"></i> Back to login</a>
      </form>
    </div>

  </div>

  <div class="footer">
    <p>Copyright <?=date('Y')?> © CC Booksy. Designed & Developed by Christos Christoforou.</p>
  </div>

</body>
</html>
