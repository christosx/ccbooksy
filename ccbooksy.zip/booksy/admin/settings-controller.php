<?php require_once('set_session.php'); ?>
<?php require_once('../functions.php'); ?>

<?php 

if (isset($_POST['btn_submit_settings'])) {
	// workers input
	$workers = $_POST['workersInput'];

	//Working days checkboxes
	$workingDayMon = $_POST['workingDaysInput_mon'];
	$workingDayTue = $_POST['workingDaysInput_tue'];
	$workingDayWed = $_POST['workingDaysInput_wed'];
	$workingDayThu = $_POST['workingDaysInput_thu'];
	$workingDayFri = $_POST['workingDaysInput_fri'];
	$workingDaySat = $_POST['workingDaysInput_sat'];
	$workingDaySun = $_POST['workingDaysInput_sun'];

	// Working Hours
	$working_time_start = $_POST['select-working-time-start'];
	$working_time_end = $_POST['select-working-time-end'];

	// Break Hours
	$break_time_start = $_POST['select-break-time-start'];
	$break_time_end = $_POST['select-break-time-end'];

	// Half days checkboxes
	$halfDayMon = $_POST['halfWorkingDaysInput_mon'];
	$halfDayTue = $_POST['halfWorkingDaysInput_tue'];
	$halfDayWed = $_POST['halfWorkingDaysInput_wed'];
	$halfDayThu = $_POST['halfWorkingDaysInput_thu'];
	$halfDayFri = $_POST['halfWorkingDaysInput_fri'];
	$halfDaySat = $_POST['halfWorkingDaysInput_sat'];
	$halfDaySun = $_POST['halfWorkingDaysInput_sun'];

	// Half days working hours
	$halfDay_time_start = $_POST['select-halfday-working-time-start'];
	$halfDay_time_end = $_POST['select-halfday-working-time-end'];

	// Appointment time span
	$app_time_span = $_POST['select-time-span'];

	// Public holidays
	$public_holidays = esc($_POST['public-holidays']);

	// Personal Holidays
	if (isset($_POST['personal_holidays_num'])) {
		$personal_hol_num = $_POST['personal_holidays_num'];
	}

	// data values for db
	$data = [];

	// workers
	$data['workers'] = $workers;

	// working days
	$workingDaysArray = array();
	if ($workingDayMon == true) {
		array_push($workingDaysArray, 'Mon');
	}
	if ($workingDayTue == true) {
		array_push($workingDaysArray, 'Tue');
	}
	if ($workingDayWed == true) {
		array_push($workingDaysArray, 'Wed');
	}
	if ($workingDayThu == true) {
		array_push($workingDaysArray, 'Thu');
	}
	if ($workingDayFri == true) {
		array_push($workingDaysArray, 'Fri');
	}
	if ($workingDaySat == true) {
		array_push($workingDaysArray, 'Sat');
	}
	if ($workingDaySun == true) {
		array_push($workingDaysArray, 'Sun');
	}
	$workingDays = implode(',', $workingDaysArray);
	$data['working_days'] = $workingDays;

	// working hours
	$working_hours = $working_time_start . '-' . $working_time_end;
	$data['working_hours'] = $working_hours;

	// break hours
	$break = $break_time_start . '-' . $break_time_end;
	$data['break_hours'] = $break;

	// half days
	$halfDaysArray = array();
	if ($halfDayMon == true) {
		array_push($halfDaysArray, 'Mon');
	}
	if ($halfDayTue == true) {
		array_push($halfDaysArray, 'Tue');
	}
	if ($halfDayWed == true) {
		array_push($halfDaysArray, 'Wed');
	}
	if ($halfDayThu == true) {
		array_push($halfDaysArray, 'Thu');
	}
	if ($halfDayFri == true) {
		array_push($halfDaysArray, 'Fri');
	}
	if ($halfDaySat == true) {
		array_push($halfDaysArray, 'Sat');
	}
	if ($halfDaySun == true) {
		array_push($halfDaysArray, 'Sun');
	}
	$halfDays = implode(',', $halfDaysArray);
	$data['half_days'] = $halfDays;

	// half days working hours
	$half_days_working_hours = $halfDay_time_start . '-' . $halfDay_time_end;
	$data['half_days_hours'] = $half_days_working_hours;

	// appointment time span
	$data['app_time_span'] = $app_time_span;

	// public holidays
	$data['public_holidays'] = $public_holidays;

	// personal holidays
	$perHolStart_array = array();
	$perHolEnd_array = array();
	$perHolWorkers_array = array();
	for ($x = 1; $x <= $personal_hol_num; $x++) {
		array_push($perHolStart_array, $_POST['startDateHol_'.$x]);
		array_push($perHolEnd_array, $_POST['endDateHol_'.$x]);
		array_push($perHolWorkers_array, $_POST['workersHol_'.$x]);
	}
	$count_perHol = count($perHolStart_array);
	$perHolString = '';
	for ($y = 0; $y < $count_perHol; $y++) {
		$ph_num = $y + 1;
		if ($count_perHol >= 1 && $y < $count_perHol - 1) {
			$perHolString .= 'ph'.$ph_num.'(start='.$perHolStart_array[$y].',end='.$perHolEnd_array[$y].',workers='.$perHolWorkers_array[$y].')|';
		} else {
			$perHolString .= 'ph'.$ph_num.'(start='.$perHolStart_array[$y].',end='.$perHolEnd_array[$y].',workers='.$perHolWorkers_array[$y].')';
		}
	}
	$data['personal_holidays'] = esc($perHolString);

	// query select
	$query_sel = "select * from settings;";
	$rows = query($query_sel);

	$data['id'] = 1;

	if ($rows) {
		$query = "update settings set id = :id, workers = :workers, working_days = :working_days, working_hours = :working_hours, break_hours = :break_hours, half_days = :half_days, half_days_hours = :half_days_hours, app_time_span = :app_time_span, public_holidays = :public_holidays, personal_holidays = :personal_holidays where id = 1;";
		query($query, $data);
	} else {
		$query = "insert into settings (id, workers, working_days, working_hours, break_hours, half_days, half_days_hours, app_time_span, public_holidays, personal_holidays) values (:id, :workers, :working_days, :working_hours, :break_hours, :half_days, :half_days_hours, :app_time_span, :public_holidays, :personal_holidays);";
		query($query, $data);
	}

	set_message("Settings saved successfully!");

	header('Location: settings.php?save=success');
}