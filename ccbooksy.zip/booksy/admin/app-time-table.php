<?php require_once('../functions.php'); ?>

<?php
	$appDay = $_POST['day'];
	$appMonth = $_POST['month'];
	$appYear = $_POST['year'];
	$appFullDate = esc($appDay . ' ' . $appMonth . ' ' . $appYear);

	$appDayName = date('D', strtotime($appFullDate));

	// get settings values from db
	$query_val = "select * from settings limit 1;";
	$row_val = query_row($query_val);

	if ($row_val) {
		$time_span = $row_val['app_time_span'];

		$breakHours = $row_val['break_hours'];
		$position = strpos($breakHours, '-'); // remove after
		if ($position !== false) {
		  $break_start = substr($breakHours, 0, $position);
		  $break_start = $break_start * 60;
		}
		$break_end = strstr($breakHours, '-'); // remove before
		$break_end = ltrim($break_end, $break_end[0]); // remove first character of the string
		$break_end = $break_end * 60;

		$halfDays = $row_val['half_days'];
		$half_days = array();
		$half_days = explode(',', $halfDays);

		$total_workers = $row_val['workers'];
		$personalHolidays = $row_val['personal_holidays'];

		if (in_array($appDayName, $half_days)) {
			$halfDaysHours = $row_val['half_days_hours'];

			$position = strpos($halfDaysHours, '-'); // remove after
			if ($position !== false) {
			  $start_time = substr($halfDaysHours, 0, $position);
			  $start_time = $start_time * 60;
			}
			$end_time = strstr($halfDaysHours, '-'); // remove before
			$end_time = ltrim($end_time, $end_time[0]); // remove first character of the string
			$end_time = $end_time * 60;
		} else {
			$workingHours = $row_val['working_hours'];

			$position = strpos($workingHours, '-'); // remove after
			if ($position !== false) {
			  $start_time = substr($workingHours, 0, $position);
			  $start_time = $start_time * 60;
			}
			$end_time = strstr($workingHours, '-'); // remove before
			$end_time = ltrim($end_time, $end_time[0]); // remove first character of the string
			$end_time = $end_time * 60;
		}
	} else {
		$time_span = 30; // 30 minutes
		$break_start = 13.00 * 60;
		$break_end = 15.00 * 60;
		$half_days = array('Sat');
		$total_workers = 2;
		$personalHolidays = '';

		if (in_array($appDayName, $half_days)) {
			$start_time = 8.00 * 60;
			$end_time = 13.00 * 60;
		} else {
			$start_time = 8.00 * 60;
			$end_time = 19.00 * 60;
		}
	}
	

	date_default_timezone_set("Europe/Athens"); // set your timezone here
	$current_time = date("H:i");
	$current_time = substr($current_time, 0, strpos($current_time, ":"));
	$current_hour = intval($current_time);
	$current_day_number = date('j');
	$current_month  = date('F');
	$current_year  = date('Y');
	$current_date_check = false;

	if ($appDay == $current_day_number && $appMonth == $current_month && $appYear == $current_year) {
		$current_date_check = true;
	}
?>

<?php 
	if (isset($_POST['inactive_workers'])) {
		$inactive_workers = $_POST['inactive_workers'];
	} else {
		$inactive_workers = 0;
	}
	$workers = $total_workers - $inactive_workers;
	$slots = $workers;
?>

<input type="hidden" name="workersInput" id="workersInput" value="<?=$workers?>">
<input type="hidden" name="personaHolidaysInput" id="personaHolidaysInput" value="<?=$personalHolidays?>">

<?php 
	// $perHolArray = explode('|', $personalHolidays);
	// $countPerHol = count($perHolArray);

	// for ($i = 0; $i < $countPerHol; $i++) {
	// 	$perHolStart = substr($perHolArray[$i], 0, strpos($perHolArray[$i], ",end")); // removes the string after a certain character
	// 	$perHolStart = strstr($perHolStart, 'start='); // removes the string before a certain character
	// 	$perHolStart = str_replace('start=', '', $perHolStart); // remove specific characters from the string
	// 	$perHolStartArray = explode('/', $perHolStart); // add holiday start into array
	// 	$perHolStartDay = $perHolStartArray[0];
	// 	$perHolStartMonth = $perHolStartArray[1];
	// 	$perHolStartYear = $perHolStartArray[2];
	// }
?>

<span class="input-title">Appointment Time (required) <i class="fa-solid fa-circle-info time-table-info"></i><span class="info-label">The following time table indicates the time and allowed persons for each slot</span></span>
<ul class="time-table-content">

	<div id="app-time-table-loader"><div class="loader"></div></div>

<?php
	$work_hours = $end_time - $start_time;
	$time_array = array();
	$count_time = array();

	for ($i=$start_time; $i<$end_time; $i+=$time_span) {
		if ( !($i>=$break_start && $i<$break_end)) {
			$raw_time = floor($i/60) . "." . ($i%60);
			$raw_time = number_format((float)$raw_time, 2, '.', '');
			$time = str_replace(".",":",$raw_time);

			$timestamp_hour = substr($time, 0, strpos($time, ":"));
			
			$query = "select persons_number, app_time from appointments where (app_full_date like '$appFullDate%') and (app_full_date like '%$appFullDate') ORDER BY id asc;";
			$rows = query($query);
			
			if($rows) {
				$counter = 0;
				$last_time = 0;
				$show_once = true;
				foreach ($rows as $row) {
					if ($row['app_time'] == $time) {
						if (!in_array($time, $time_array)) {
							array_push($time_array, $time);
						}

						array_push($count_time, $time);

						if ($row['persons_number'] < $workers) {
							$slots = $workers - intval($row['persons_number']);
						} elseif ($row['persons_number'] == $workers) {
							$slots = 0;
						}

						foreach ($count_time as $c_time) {
							if ($time == $c_time) {
								$counter = $counter + $row['persons_number'];
							}
						}

						$data_sum = [];
						$data_sum['time'] = $time;
						$query_sum = "select sum(persons_number) as count from appointments where app_time = :time and (app_full_date like '$appFullDate%') and (app_full_date like '%$appFullDate');";
						$rows_sum = query($query_sum, $data_sum);

						foreach ($rows_sum as $sum) {
							if ($sum['count'] >= $workers) {
								$slots = 0;
							} else {
								$slots = $workers - $sum['count']; 
							}
						} 

						if ($last_time == $row['app_time']) {
							$show_once = false;
						} else {
							$show_once = true;
						}

						if ($counter <= $workers && $show_once == true) {
							if ($slots == 0 || ($current_hour > substr($time, 0, strpos($time, ":")) && $current_date_check == true)) {
								echo '<li class="time-stamp inactive-time-stamp">' . $time . ' ('. $slots .')</li>';
							} else {
								echo '<li class="time-stamp">' . $time . ' ('. $slots .')</li>';
							}
						}
					}

					$last_time = $row['app_time'];
				}
			}

			if (!in_array($time, $time_array)) {
				$slots = $workers;
				if ($slots == 0 || ($current_hour > substr($time, 0, strpos($time, ":")) && $current_date_check == true)) {
					echo '<li class="time-stamp inactive-time-stamp">' . $time . ' ('. $slots .')</li>';
				} else {
					echo '<li class="time-stamp">' . $time . ' ('. $slots .')</li>';
				}
			}
		}
	}
?>
</ul>
<span id="time-info" class="validate-info"></span>