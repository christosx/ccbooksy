<?php require_once('../functions.php'); ?>

<?php 
	date_default_timezone_set("Europe/Athens"); // set your timezone here
	$currentDay = date('j');
	$currentMonth  = date('n');
	$currentYear  = date('Y');
	$currentDateNumeric = $currentYear . '-' . $currentMonth . '-' . $currentDay;
?>

<div class="date-area">
<?php
	$query = "select * from appointments order by app_full_date_numeric asc;";
	$rows = query($query);

	if($rows) {
		$date_array = array();
		foreach ($rows as $row) {
			if (!in_array($row['app_full_date_numeric'], $date_array)) {
				if ($row['app_full_date_numeric'] >= $currentDateNumeric) {
					array_push($date_array ,$row['app_full_date_numeric']);
				}

				if ($row['app_full_date_numeric'] < $currentDateNumeric) { // delete from database if date is passed
					$data_del = [];
					$data_del['app_full_date_numeric'] = $row['app_full_date_numeric'];
					$query_del = "delete from appointments where app_full_date_numeric = :app_full_date_numeric;";
					query($query_del, $data_del);
				}
			}
		}
	}

	usort($date_array, function ($a, $b) { // sort asc
	    return strtotime($a) - strtotime($b);
	});
	
	$count = count($date_array);

	if (isset($_POST['page'])) {
		$page = $_POST['page'];
	} else {
		$page = $_GET['page'];
	}

	$selector = $page - 1;
	$query = "select * from appointments where (app_full_date_numeric like '$date_array[$selector]%') and (app_full_date_numeric like '%$date_array[$selector]') order by app_time_numeric asc;";
	$rows = query($query);

	$selector = 0;


	if ($rows) {
		if ($rows[$selector]['app_day_name'] == 'Mon') {
			$day_name = 'Monday';
		} elseif ($rows[$selector]['app_day_name'] == 'Tue') {
			$day_name = 'Tuesday';
		} elseif ($rows[$selector]['app_day_name'] == 'Wed') {
			$day_name = 'Wednesday';
		} elseif ($rows[$selector]['app_day_name'] == 'Thu') {
			$day_name = 'Thursday';
		} elseif ($rows[$selector]['app_day_name'] == 'Fri') {
			$day_name = 'Friday';
		} elseif ($rows[$selector]['app_day_name'] == 'Sat') {
			$day_name = 'Saturday';
		} elseif ($rows[$selector]['app_day_name'] == 'Sun') {
			$day_name = 'Sunday';
		}

		echo '<span class="date">' . $day_name . ' ' . $rows[$selector]['app_full_date'] . '</span>';
		
		if ($page != $count) {
			echo '<div class="nav-date"><i class="fa-solid fa-angle-left nav-date-prev" onclick="navDatePrev();"></i><i class="fa-solid fa-angle-right nav-date-next" onclick="navDateNext();"></i></div>';
		} else {
			echo '<div class="nav-date"><i class="fa-solid fa-angle-left nav-date-prev" onclick="navDatePrev();"></i><i class="fa-solid fa-angle-right nav-date-next"></i></div>';
		}
	}
?>
</div>

<ul class="app-content">
<?php 
	if($rows) {
		echo '<ul>';
		foreach ($rows as $row) {
			echo '<li>';
			echo '<span class="full-name"><i class="fa-solid fa-user"></i>' . $row['full_name'] . '</span>';
			echo '<span class="phone-number"><i class="fa-solid fa-phone"></i>' . $row['phone_number'] . '</span>';
			if ($row['persons_number'] == 1) {
				echo '<span class="persons-number"><i class="fa-solid fa-users"></i>' . $row['persons_number'] . ' person</span>';
			} else {
				echo '<span class="persons-number"><i class="fa-solid fa-users"></i>' . $row['persons_number'] . ' persons</span>';
			}
			echo '<span class="app-time"><i class="fa-solid fa-clock"></i>' . $row['app_time'] . '</span>';
			// echo '<i class="fa-solid fa-circle-xmark delete-row-icon" onclick="deleteApp('.$row['id'].', '.$row['full_name'].', '.$row['app_time'].', '.$row['persons_number'].');"></i>';
			?><i class="fa-solid fa-circle-xmark delete-row-icon" onclick="deleteApp('<?=$row['id']?>', '<?=$row['full_name']?>', '<?=$row['app_time']?>', '<?=$row['persons_number']?>');"></i><?php
			echo '</li>';
		}
		echo '</ul>';
	}
?>
</ul>