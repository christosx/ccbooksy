var date = new Date();
var year = date.getFullYear();
var month = date.getMonth();

const day = document.querySelector(".calendar-dates");

const currdate = document
	.querySelector(".calendar-current-date");

const prenexIcons = document
	.querySelectorAll(".calendar-navigation span");

// Array of month names
const months = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];

// variables for personal holidays
var personalHolidays = $("#personaHolidaysInput").val();
var personalHolidaysArray = personalHolidays.split("|");
var perHolArrayN = [];
var totalWorkers = $("#workersInput").val();
personalHolidaysArray.forEach(perHolFunction);

function perHolFunction(item) {
	var perHolStartDate = item.slice(item.indexOf('start=') + 6); // get string after a specific character
	var perHolStartDate = perHolStartDate.substring(0, perHolStartDate.indexOf(',end=')); // get string before a specific character
	var perHolStartDateArray = perHolStartDate.split("/");
	var perHolStartMonth = perHolStartDateArray[1] - 1;
	
	var perHolEndDate = item.slice(item.indexOf('end=') + 4); // get string after a specific character
	var perHolEndDate = perHolEndDate.substring(0, perHolEndDate.indexOf(',workers=')); // get string before a specific character
	var perHolEndDateArray = perHolEndDate.split("/");
	var perHolEndMonth = perHolEndDateArray[1] - 1;

	var perHolWorkers = item.slice(item.indexOf('workers=') + 8); // get string after a specific character
	var perHolWorkers = perHolWorkers.substring(0, perHolWorkers.indexOf(')')); // get string before a specific character

	var perHolMonthDif = perHolEndDateArray[1] - perHolStartDateArray[1];

	perHolArrayN.push([perHolStartDateArray[0],perHolStartMonth,perHolStartDateArray[2],perHolEndDateArray[0],perHolEndMonth,perHolEndDateArray[2],perHolWorkers,perHolMonthDif]);
}

var countLength = perHolArrayN.length;

// Function to generate the calendar
const manipulate = () => {

	// Get the first day of the month
	let dayone = new Date(year, month, 1).getDay();

	// Get the last date of the month
	let lastdate = new Date(year, month + 1, 0).getDate();

	// Get the day of the last date of the month
	let dayend = new Date(year, month, lastdate).getDay();

	// Get the last date of the previous month
	let monthlastdate = new Date(year, month, 0).getDate();

	// Variable to store the generated calendar HTML
	let lit = "";

	// Loop to add the last dates of the previous month
	for (let i = dayone; i > 0; i--) {
		lit +=
			`<li class="inactive">${monthlastdate - i + 1}</li>`;
	}

	// Loop to add the dates of the current month
	for (let i = 1; i <= lastdate; i++) {

		// Check if the date is in the past
		let pastDay = i < date.getDate()
			&& month === new Date().getMonth()
			&& year === new Date().getFullYear()
			? "inactive"
			: "";

		// Check if the current date is today
		let isToday = i === date.getDate()
			&& month === new Date().getMonth()
			&& year === new Date().getFullYear()
			? "active"
			: "";
		
		lit += `<li onclick="getDateValue('${i}');" class="date-number date-number-${i} date-number-${i}-m${month}-y${year} ${isToday} ${pastDay}">${i}</li>`;

		// if personal holidays
		$( document ).ready(function() {
			for (var x = 0; x < countLength; x++) {
				
				if ((totalWorkers - perHolArrayN[x][6]) == 0) {
					if (perHolArrayN[x][7] == 0) {
						// Check if the date is the start of a personal holiday
						if( i >= perHolArrayN[x][0] && month == perHolArrayN[x][1] && year == perHolArrayN[x][2] && i <= perHolArrayN[x][3] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive');
						}
					} else {
						// Check if the date is the start of a personal holiday
						if ( i >= perHolArrayN[x][0] && month == perHolArrayN[x][1] && year == perHolArrayN[x][2] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive');
						}

						// Check if the date is the end of a personal holiday
						if ( i >= 1 && month == perHolArrayN[x][4] && year == perHolArrayN[x][5] && i <= perHolArrayN[x][3] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive');
						}
					}
				} else if ((totalWorkers - perHolArrayN[x][6]) > 0) {
					if (perHolArrayN[x][7] == 0) {
						// Check if the date is the start of a personal holiday
						if( i >= perHolArrayN[x][0] && month == perHolArrayN[x][1] && year == perHolArrayN[x][2] && i <= perHolArrayN[x][3] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive-workers workers-'+perHolArrayN[x][6]);	
						}
					} else {
						// Check if the date is the start of a personal holiday
						if ( i >= perHolArrayN[x][0] && month == perHolArrayN[x][1] && year == perHolArrayN[x][2] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive-workers workers-'+perHolArrayN[x][6]);
						}

						// Check if the date is the end of a personal holiday
						if ( i >= 1 && month == perHolArrayN[x][4] && year == perHolArrayN[x][5] && i <= perHolArrayN[x][3] ) {
							$('.date-number-'+i+'-m'+month+'-y'+year).addClass('inactive-workers workers-'+perHolArrayN[x][6]);
						}
					}
				}

			}
		});
		

	}

	// Loop to add the first dates of the next month
	for (let i = dayend; i < 6; i++) {
		lit += `<li class="inactive">${i - dayend + 1}</li>`
	}

	// remove 'selected' class
	$('.calendar-dates').click(function(e) {  
        $(".calendar-dates .selected-date").removeClass("selected-date");
    });
	
	// add 'selected' class on clicked date
	document.addEventListener('click', function handleClick(event) {
		if (event.target.classList.contains('inactive')) {
			// do nothing
		} else if (event.target.classList.contains('date-number')){
			event.target.classList.add('selected-date');
		}
	});

	// Update the text of the current date element 
	// with the formatted current month and year
	currdate.innerText = `${months[month]} ${year}`;

	// update the HTML of the dates element 
	// with the generated calendar
	day.innerHTML = lit;

	// assign array
	var offDays = [];
	var publicHolidays = [];

	// add 'inactive' class to 'date-number' element
	var divElements = document.querySelectorAll('.date-number');
	divElements.forEach(element => {
		var el_num = element.innerHTML;
		var el_monthYear = $('.calendar-current-date').text(); // get content of a div
		let el_words = el_monthYear;
		var el_wordArray = [];
		el_wordArray = el_words.split(' ');
		var el_month = el_wordArray[0];
		var el_year = el_wordArray[1];

		if (el_month == 'January') {
			el_month_num = 1;
		} else if (el_month == 'February') {
			el_month_num = 2;
		} else if (el_month == 'March') {
			el_month_num = 3;
		} else if (el_month == 'April') {
			el_month_num = 4;
		} else if (el_month == 'May') {
			el_month_num = 5;
		} else if (el_month == 'June') {
			el_month_num = 6;
		} else if (el_month == 'July') {
			el_month_num = 7;
		} else if (el_month == 'August') {
			el_month_num = 8;
		} else if (el_month == 'September') {
			el_month_num = 9;
		} else if (el_month == 'October') {
			el_month_num = 10;
		} else if (el_month == 'November') {
			el_month_num = 11;
		} else if (el_month == 'December') {
			el_month_num = 12;
		}

		var el_day = new Date(el_year+'-'+el_month_num+'-'+el_num); //ISO8601 format is better for Firefox
		var calendarDay = el_day.getDay();

		// add 'inactive' class to 'date-number' element if is off day
		var work_days = $("#working_days_hidden_input").val();
		var work_d_array = work_days.split(",");
		
		work_d_array.forEach(day_el => {
			if (day_el != 'Mon') {
				if (!work_d_array.includes('Mon') && !offDays.includes('1')) {
					offDays.push('1');
				}
			}
			if (day_el != 'Tue') {
				if (!work_d_array.includes('Tue') && !offDays.includes('2')) {
					offDays.push('2');
				}
			}
			if (day_el != 'Wed') {
				if (!work_d_array.includes('Wed') && !offDays.includes('3')) {
					offDays.push('3');
				}
			}
			if (day_el != 'Thu') {
				if (!work_d_array.includes('Thu') && !offDays.includes('4')) {
					offDays.push('4');
				}
			}
			if (day_el != 'Fri') {
				if (!work_d_array.includes('Fri') && !offDays.includes('5')) {
					offDays.push('5');
				}
			}
			if (day_el != 'Sat') {
				if (!work_d_array.includes('Sat') && !offDays.includes('6')) {
					offDays.push('6');
				}
			}
			if (day_el != 'Sun') {
				if (!work_d_array.includes('Sun') && !offDays.includes('0')) {
					offDays.push('0');
				}
			}
		});

		if (offDays.includes('0') && calendarDay == '0') {
			element.className = "inactive";
		}

		if (offDays.includes('1') && calendarDay == '1') {
			element.className = "inactive";
		}

		if (offDays.includes('2') && calendarDay == '2') {
			element.className = "inactive";
		}

		if (offDays.includes('3') && calendarDay == '3') {
			element.className = "inactive";
		}

		if (offDays.includes('4') && calendarDay == '4') {
			element.className = "inactive";
		}

		if (offDays.includes('5') && calendarDay == '5') {
			element.className = "inactive";
		}

		if (offDays.includes('6') && calendarDay == '6') {
			element.className = "inactive";
		}

		// add 'inactive' class to 'date-number' element if is a public holiday
		var public_holidays = $("#public_holidays_hidden_input").val();
		var public_h_array = public_holidays.split(",");

		public_h_array.forEach(hol_el => {
			if (!publicHolidays.includes(hol_el)) {
				publicHolidays.push(hol_el);
			}
		});

		publicHolidays.forEach(item => {

			var item_day = item.split('/')[0]; // Remove everything after the first occurrence of a character
			var item_month = item.split('/').pop(); // Removes part of string before

			if (el_num == item_day && item_month == '1' && el_month == 'January') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '2' && el_month == 'February') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '3' && el_month == 'March') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '4' && el_month == 'April') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '5' && el_month == 'May') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '6' && el_month == 'June') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '7' && el_month == 'July') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '8' && el_month == 'August') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '9' && el_month == 'September') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '10' && el_month == 'October') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '11' && el_month == 'November') {
				element.className = "inactive";
			}

			if (el_num == item_day && item_month == '12' && el_month == 'December') {
				element.className = "inactive";
			}

		});

	});

}

manipulate();

// Attach a click event listener to each icon
prenexIcons.forEach(icon => {

	// When an icon is clicked
	icon.addEventListener("click", () => {

		// Check if the icon is "calendar-prev"
		// or "calendar-next"
		if (month == date.getMonth() && year == date.getFullYear()) {
			month = icon.id === "calendar-prev" ? month : month + 1;
		} else {
			month = icon.id === "calendar-prev" ? month - 1 : month + 1;
		}

		// Check if the month is out of range
		if (month < 0 || month > 11) {

			// Set the date to the first day of the 
			// month with the new year
			date = new Date(year, month, new Date().getDate());

			// Set the year to the new year
			year = date.getFullYear();

			// Set the month to the new month
			month = date.getMonth();
		}

		else {

			// Set the date to the current date
			date = new Date();
		}

		// Call the manipulate function to 
		// update the calendar display
		manipulate();
	});
});
